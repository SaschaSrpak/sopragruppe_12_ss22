import React, { Component } from 'react';

/**
 *@fileOverview
 *@author Luca Trautmann
*/

export class Footer extends Component{
    constructor(props){
        super(probs)


        this.state= {

        }
    }

    render() {
        
          const { classes, apiUser } = this.props;
          
          return
      }
    }


Footer.propTypes={
    classes: PropTypes.object.isRequired
};
export default Footer;
       

