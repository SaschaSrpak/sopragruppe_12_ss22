import React, { Component } from 'react';

/* 
 *@fileOverview 
 *@author Kim Kausler
*/

class Loader extends Component {
    render()
}

export default LoadingProgess;