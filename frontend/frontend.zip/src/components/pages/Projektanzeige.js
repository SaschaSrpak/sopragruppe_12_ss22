import React, { Component } from "react";

/** 
 *@fileOverview 
 *@author Sascha Srpak
*/

export class Projektanzeige extends Component {
    render() {
        return (
            <div>
                <h1>Projektanzeige Testpage</h1>
            </div>
        );
    }
}

export default Projektanzeige;