/** 
 *@fileOverview 
 *@author
*/
import React, { Component } from "react";

export class Home extends Component {



    render() {
        return (
            <p> wir sind auf der homepage</p>)
    }
}

export default Home;