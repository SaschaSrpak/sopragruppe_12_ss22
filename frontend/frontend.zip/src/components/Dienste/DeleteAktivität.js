import React, {Component} from 'react'
import Error from '../Zwischenelemente/Error'


export class DeleteAktivität extends Component {
    constructor(props){
        super(props)
    }

    render(){

    }
}