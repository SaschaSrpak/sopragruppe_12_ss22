import React, {Component} from 'react'
import Error from '../Zwischenelemente/Error'


export class DeleteProjekt extends Component {
    constructor(props){
        super(props)
    }

    render(){

    }
}