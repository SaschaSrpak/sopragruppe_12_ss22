import React, {Component} from 'react'
import Error from '../Zwischenelemente/Error'


export class NewProjekt extends Component {
    constructor(props){
        super(props)
    }


    render(){

    }
}