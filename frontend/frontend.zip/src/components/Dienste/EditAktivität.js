import React, {Component} from 'react'
import Error from '../Zwischenelemente/Error'


export class EditAktivität extends Component {
    constructor(props){
        super(props)
    }

    render(){

    }
}