/** 
 *@fileOverview 
 *@author Luca Trautmann
*/
 

export class Registrierung extends Component {


constructor(props) {
        super(props);
        var person = new PersonBO()
        //set alle Daten from currentUser
        
        person.setName(this.props.currentUser.name)
        person.setSurename(this.props.currentUser.Surename)
        person.setMail_adress(this.props.currentUser.Mail)
        person.setUser_name(this.props.currentUser.username)
        person.setFirebase_id(this.props.currentUser.uid)
       
        //set default values manager erstmal auf 1 zum codieren
        person.setManager_status(1)
   
        this.state = {
                appError: null,
                person: person,
                activeStep: 0,
                open: false,
                classes: props,
                disabledButtonvalue: false,
            };
        }

        
}
