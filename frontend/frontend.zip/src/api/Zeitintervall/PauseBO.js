import PauseBO from './Zeitintervall/PauseBO';
/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class PauseBO{

    constructor() {
           }

    
}