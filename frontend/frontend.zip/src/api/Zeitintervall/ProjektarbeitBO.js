import ProjektarbeitBO from './Zeitintervall/ProjektarbeitBO';
/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class ProjektarbeitBO{

    constructor() {
           }

    
}