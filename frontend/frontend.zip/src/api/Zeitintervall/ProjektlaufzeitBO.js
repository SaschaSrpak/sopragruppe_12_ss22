import ProjektlaufzeitBO from './Zeitintervall/ProjektlaufzeitBO';
/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class ProjektlaufzeitBO{

    constructor() {
           }

    
}