import KommenBO from "/Ereignisse/KommenBO";
/** 
 *@fileOverview 
 *@author Luca Trautmann, Kim Kausler
*/

export default class KommenBO extends KommenBO{

    constructor() {
        super()
           }

    
}