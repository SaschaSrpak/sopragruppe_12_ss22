import StartereignisBO from "/Ereignisse/StartereignisBO";
/** 
 *@fileOverview 
 *@author Luca Trautmann, Kim Kausler
*/

export default class StartereignisBO extends StartereignisBO{

    constructor() {
        super()
    }
           }
