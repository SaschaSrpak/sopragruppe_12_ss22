import ProjektDeadlineBO from "/Ereignisse/ProjektDeadlineBO";
/** 
 *@fileOverview 
 *@author Luca Trautmann, Kim Kausler
*/

export default class ProjektDeadlineBO extends ProjektDeadlineBO{


    constructor() {
        super()
           }

    
}