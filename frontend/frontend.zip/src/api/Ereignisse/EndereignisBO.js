import EndereignisBO from "/Ereignisse/EndereignisBO";
/** 
 *@fileOverview 
 *@author Luca Trautmann, Kim Kausler
*/

export default class EndereignisBO extends EndereignisBO{

    constructor() {
        super()
           }

    
}