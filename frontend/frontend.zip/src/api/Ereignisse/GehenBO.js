import GehenBO from "/Ereignisse/GehenBO";
/** 
 *@fileOverview 
 *@author Luca Trautmann, Kim Kaussler
*/

export default class GehenBO extends GehenBO{

    constructor() {
        super()
           }

    
}