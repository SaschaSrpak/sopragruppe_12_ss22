import GehenBuchungBO from './Buchungen/GehenBuchungBO';
import EreignisbuchungBO from './EreignisbuchungBO';

/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class GehenBuchungBO extends EreignisbuchungBO{

    constructor() {
        super()    
    }

    
}