import KommenBuchungBO from './Buchungen/KommenBuchungBO';
import EreignisbuchungBO from './EreignisbuchungBO';

/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class KommenBuchungBO extends EreignisbuchungBO{

    constructor() {
        super()       
    }

    
}