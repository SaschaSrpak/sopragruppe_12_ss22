import EndereignisBuchungBO from './Buchungen/EndereignisBuchungBO';
import EreignisbuchungBO from './EreignisbuchungBO';

/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class EndereignisBuchungBO extends EreignisbuchungBO{

    constructor() {
        super()
    }

    
}