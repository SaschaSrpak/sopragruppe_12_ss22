import StartereignisBuchungBO from './Buchungen/StartereignisBuchungBO';
import EreignisbuchungBO from './EreignisbuchungBO';

/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class StartereignisBuchungBO extends EreignisbuchungBO{

    constructor() {
        super()       
    }

    
}