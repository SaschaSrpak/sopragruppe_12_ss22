import PauseBuchungBO from './Buchungen/PauseBuchungBO';
import ZeitintervallbuchungBO from './ZeitintervallbuchungBO';

/** 
 *@fileOverview 
 *@author Luca Trautmann
*/

export default class PauseBuchungBO extends ZeitintervallbuchungBO{

    constructor() {
        super()       
    }

    
}